# LinuxBattery
## Acerca de:
### Esta Aplicacion fue hecha con el proposito de hacer pruebas para obtener datos de la terminal y que la aplicacion pueda interpretarlos y tambien debido a que en mi distribucion actual **Linux Lite** aun no me acostumbro a buscar la informacion de la bateria por lo que opte por diseñar una aplicacion que me sea mas comoda.  

## Preview 
 <img src="src/Draw/btPreview.png">  

## Ejecutar Aplicacion
### ....